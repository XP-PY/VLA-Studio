# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${picasso_localization_DIR}/.." "msg" picasso_localization_MSG_INCLUDE_DIRS UNIQUE)
set(picasso_localization_MSG_DEPENDENCIES geometry_msgs;std_msgs;nav_msgs;sensor_msgs)
