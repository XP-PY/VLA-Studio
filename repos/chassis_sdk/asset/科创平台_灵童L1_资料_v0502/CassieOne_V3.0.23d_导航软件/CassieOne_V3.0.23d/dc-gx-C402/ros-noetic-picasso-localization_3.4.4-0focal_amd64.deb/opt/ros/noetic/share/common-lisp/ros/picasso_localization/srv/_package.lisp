(cl:defpackage picasso_localization-srv
  (:use )
  (:export
   "CTRLCMD"
   "<CTRLCMD-REQUEST>"
   "CTRLCMD-REQUEST"
   "<CTRLCMD-RESPONSE>"
   "CTRLCMD-RESPONSE"
  ))

