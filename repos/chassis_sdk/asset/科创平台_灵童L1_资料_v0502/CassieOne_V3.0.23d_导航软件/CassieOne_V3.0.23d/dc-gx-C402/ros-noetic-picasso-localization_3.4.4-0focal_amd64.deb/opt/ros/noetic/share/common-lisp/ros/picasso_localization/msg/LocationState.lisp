; Auto-generated. Do not edit!


(cl:in-package picasso_localization-msg)


;//! \htmlinclude LocationState.msg.html

(cl:defclass <LocationState> (roslisp-msg-protocol:ros-message)
  ((mode
    :reader mode
    :initarg :mode
    :type cl:fixnum
    :initform 0)
   (state
    :reader state
    :initarg :state
    :type cl:fixnum
    :initform 0)
   (laser_score
    :reader laser_score
    :initarg :laser_score
    :type cl:float
    :initform 0.0)
   (laser_x
    :reader laser_x
    :initarg :laser_x
    :type cl:float
    :initform 0.0)
   (laser_y
    :reader laser_y
    :initarg :laser_y
    :type cl:float
    :initform 0.0)
   (laser_yaw
    :reader laser_yaw
    :initarg :laser_yaw
    :type cl:float
    :initform 0.0)
   (gnss_msg_state
    :reader gnss_msg_state
    :initarg :gnss_msg_state
    :type cl:fixnum
    :initform 0)
   (gnss_run_state
    :reader gnss_run_state
    :initarg :gnss_run_state
    :type cl:fixnum
    :initform 0)
   (satellite_num
    :reader satellite_num
    :initarg :satellite_num
    :type cl:fixnum
    :initform 0)
   (gnss_score
    :reader gnss_score
    :initarg :gnss_score
    :type cl:float
    :initform 0.0)
   (gnss_x
    :reader gnss_x
    :initarg :gnss_x
    :type cl:float
    :initform 0.0)
   (gnss_y
    :reader gnss_y
    :initarg :gnss_y
    :type cl:float
    :initform 0.0)
   (gnss_yaw
    :reader gnss_yaw
    :initarg :gnss_yaw
    :type cl:float
    :initform 0.0))
)

(cl:defclass LocationState (<LocationState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LocationState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LocationState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name picasso_localization-msg:<LocationState> is deprecated: use picasso_localization-msg:LocationState instead.")))

(cl:ensure-generic-function 'mode-val :lambda-list '(m))
(cl:defmethod mode-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:mode-val is deprecated.  Use picasso_localization-msg:mode instead.")
  (mode m))

(cl:ensure-generic-function 'state-val :lambda-list '(m))
(cl:defmethod state-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:state-val is deprecated.  Use picasso_localization-msg:state instead.")
  (state m))

(cl:ensure-generic-function 'laser_score-val :lambda-list '(m))
(cl:defmethod laser_score-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:laser_score-val is deprecated.  Use picasso_localization-msg:laser_score instead.")
  (laser_score m))

(cl:ensure-generic-function 'laser_x-val :lambda-list '(m))
(cl:defmethod laser_x-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:laser_x-val is deprecated.  Use picasso_localization-msg:laser_x instead.")
  (laser_x m))

(cl:ensure-generic-function 'laser_y-val :lambda-list '(m))
(cl:defmethod laser_y-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:laser_y-val is deprecated.  Use picasso_localization-msg:laser_y instead.")
  (laser_y m))

(cl:ensure-generic-function 'laser_yaw-val :lambda-list '(m))
(cl:defmethod laser_yaw-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:laser_yaw-val is deprecated.  Use picasso_localization-msg:laser_yaw instead.")
  (laser_yaw m))

(cl:ensure-generic-function 'gnss_msg_state-val :lambda-list '(m))
(cl:defmethod gnss_msg_state-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:gnss_msg_state-val is deprecated.  Use picasso_localization-msg:gnss_msg_state instead.")
  (gnss_msg_state m))

(cl:ensure-generic-function 'gnss_run_state-val :lambda-list '(m))
(cl:defmethod gnss_run_state-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:gnss_run_state-val is deprecated.  Use picasso_localization-msg:gnss_run_state instead.")
  (gnss_run_state m))

(cl:ensure-generic-function 'satellite_num-val :lambda-list '(m))
(cl:defmethod satellite_num-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:satellite_num-val is deprecated.  Use picasso_localization-msg:satellite_num instead.")
  (satellite_num m))

(cl:ensure-generic-function 'gnss_score-val :lambda-list '(m))
(cl:defmethod gnss_score-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:gnss_score-val is deprecated.  Use picasso_localization-msg:gnss_score instead.")
  (gnss_score m))

(cl:ensure-generic-function 'gnss_x-val :lambda-list '(m))
(cl:defmethod gnss_x-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:gnss_x-val is deprecated.  Use picasso_localization-msg:gnss_x instead.")
  (gnss_x m))

(cl:ensure-generic-function 'gnss_y-val :lambda-list '(m))
(cl:defmethod gnss_y-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:gnss_y-val is deprecated.  Use picasso_localization-msg:gnss_y instead.")
  (gnss_y m))

(cl:ensure-generic-function 'gnss_yaw-val :lambda-list '(m))
(cl:defmethod gnss_yaw-val ((m <LocationState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:gnss_yaw-val is deprecated.  Use picasso_localization-msg:gnss_yaw instead.")
  (gnss_yaw m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LocationState>) ostream)
  "Serializes a message object of type '<LocationState>"
  (cl:let* ((signed (cl:slot-value msg 'mode)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'state)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'laser_score))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'laser_x))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'laser_y))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'laser_yaw))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'gnss_msg_state)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'gnss_run_state)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'satellite_num)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'gnss_score))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'gnss_x))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'gnss_y))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'gnss_yaw))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LocationState>) istream)
  "Deserializes a message object of type '<LocationState>"
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'mode) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'state) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'laser_score) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'laser_x) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'laser_y) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'laser_yaw) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gnss_msg_state) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gnss_run_state) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'satellite_num) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gnss_score) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gnss_x) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gnss_y) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gnss_yaw) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LocationState>)))
  "Returns string type for a message object of type '<LocationState>"
  "picasso_localization/LocationState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LocationState)))
  "Returns string type for a message object of type 'LocationState"
  "picasso_localization/LocationState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LocationState>)))
  "Returns md5sum for a message object of type '<LocationState>"
  "64447d0d1b0a1f725b34418a825d3994")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LocationState)))
  "Returns md5sum for a message object of type 'LocationState"
  "64447d0d1b0a1f725b34418a825d3994")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LocationState>)))
  "Returns full string definition for message of type '<LocationState>"
  (cl:format cl:nil "int8    mode # 0:none; 1:laser; 2:gnss; 3:mix2; 4:ins(gnss+imu);~%int8    state # 0:none; 1:sleeping; 2:success; 3:error;~%float32 laser_score~%float32 laser_x~%float32 laser_y~%float32 laser_yaw~%int8    gnss_msg_state # 0:invalid; 1:single; 4:diff; 5:float; 0xFF:disconnect;~%int8    gnss_run_state # 0:none; 1:idle; 2:invalid; 3:calib_running; 4:calib_finished; 5:calib_error;~%int8    satellite_num~%float32 gnss_score~%float32 gnss_x~%float32 gnss_y~%float32 gnss_yaw~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LocationState)))
  "Returns full string definition for message of type 'LocationState"
  (cl:format cl:nil "int8    mode # 0:none; 1:laser; 2:gnss; 3:mix2; 4:ins(gnss+imu);~%int8    state # 0:none; 1:sleeping; 2:success; 3:error;~%float32 laser_score~%float32 laser_x~%float32 laser_y~%float32 laser_yaw~%int8    gnss_msg_state # 0:invalid; 1:single; 4:diff; 5:float; 0xFF:disconnect;~%int8    gnss_run_state # 0:none; 1:idle; 2:invalid; 3:calib_running; 4:calib_finished; 5:calib_error;~%int8    satellite_num~%float32 gnss_score~%float32 gnss_x~%float32 gnss_y~%float32 gnss_yaw~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LocationState>))
  (cl:+ 0
     1
     1
     4
     4
     4
     4
     1
     1
     1
     4
     4
     4
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LocationState>))
  "Converts a ROS message object to a list"
  (cl:list 'LocationState
    (cl:cons ':mode (mode msg))
    (cl:cons ':state (state msg))
    (cl:cons ':laser_score (laser_score msg))
    (cl:cons ':laser_x (laser_x msg))
    (cl:cons ':laser_y (laser_y msg))
    (cl:cons ':laser_yaw (laser_yaw msg))
    (cl:cons ':gnss_msg_state (gnss_msg_state msg))
    (cl:cons ':gnss_run_state (gnss_run_state msg))
    (cl:cons ':satellite_num (satellite_num msg))
    (cl:cons ':gnss_score (gnss_score msg))
    (cl:cons ':gnss_x (gnss_x msg))
    (cl:cons ':gnss_y (gnss_y msg))
    (cl:cons ':gnss_yaw (gnss_yaw msg))
))
