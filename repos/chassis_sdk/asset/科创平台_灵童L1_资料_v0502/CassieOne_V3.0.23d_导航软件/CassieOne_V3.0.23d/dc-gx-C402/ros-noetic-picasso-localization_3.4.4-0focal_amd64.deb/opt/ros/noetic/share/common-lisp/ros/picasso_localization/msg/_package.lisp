(cl:defpackage picasso_localization-msg
  (:use )
  (:export
   "<CLOUDINFO>"
   "CLOUDINFO"
   "<GNSSSTATE>"
   "GNSSSTATE"
   "<LOCATIONSTATE>"
   "LOCATIONSTATE"
  ))

