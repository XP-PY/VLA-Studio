; Auto-generated. Do not edit!


(cl:in-package picasso_localization-msg)


;//! \htmlinclude GnssState.msg.html

(cl:defclass <GnssState> (roslisp-msg-protocol:ros-message)
  ((state
    :reader state
    :initarg :state
    :type cl:fixnum
    :initform 0)
   (gnss_valid
    :reader gnss_valid
    :initarg :gnss_valid
    :type cl:fixnum
    :initform 0)
   (satellite_num
    :reader satellite_num
    :initarg :satellite_num
    :type cl:fixnum
    :initform 0))
)

(cl:defclass GnssState (<GnssState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <GnssState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'GnssState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name picasso_localization-msg:<GnssState> is deprecated: use picasso_localization-msg:GnssState instead.")))

(cl:ensure-generic-function 'state-val :lambda-list '(m))
(cl:defmethod state-val ((m <GnssState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:state-val is deprecated.  Use picasso_localization-msg:state instead.")
  (state m))

(cl:ensure-generic-function 'gnss_valid-val :lambda-list '(m))
(cl:defmethod gnss_valid-val ((m <GnssState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:gnss_valid-val is deprecated.  Use picasso_localization-msg:gnss_valid instead.")
  (gnss_valid m))

(cl:ensure-generic-function 'satellite_num-val :lambda-list '(m))
(cl:defmethod satellite_num-val ((m <GnssState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader picasso_localization-msg:satellite_num-val is deprecated.  Use picasso_localization-msg:satellite_num instead.")
  (satellite_num m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <GnssState>) ostream)
  "Serializes a message object of type '<GnssState>"
  (cl:let* ((signed (cl:slot-value msg 'state)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'gnss_valid)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'satellite_num)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <GnssState>) istream)
  "Deserializes a message object of type '<GnssState>"
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'state) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gnss_valid) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'satellite_num) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<GnssState>)))
  "Returns string type for a message object of type '<GnssState>"
  "picasso_localization/GnssState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'GnssState)))
  "Returns string type for a message object of type 'GnssState"
  "picasso_localization/GnssState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<GnssState>)))
  "Returns md5sum for a message object of type '<GnssState>"
  "b7977205a43280ad3cc25bb91c265bf9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'GnssState)))
  "Returns md5sum for a message object of type 'GnssState"
  "b7977205a43280ad3cc25bb91c265bf9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<GnssState>)))
  "Returns full string definition for message of type '<GnssState>"
  (cl:format cl:nil "int8    state           # 0:invalid; 1:single; 4:diff; 5:float; 0xFF:disconnect;~%int8    gnss_valid      # 0:invalid; 1:valid;~%int8    satellite_num~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'GnssState)))
  "Returns full string definition for message of type 'GnssState"
  (cl:format cl:nil "int8    state           # 0:invalid; 1:single; 4:diff; 5:float; 0xFF:disconnect;~%int8    gnss_valid      # 0:invalid; 1:valid;~%int8    satellite_num~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <GnssState>))
  (cl:+ 0
     1
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <GnssState>))
  "Converts a ROS message object to a list"
  (cl:list 'GnssState
    (cl:cons ':state (state msg))
    (cl:cons ':gnss_valid (gnss_valid msg))
    (cl:cons ':satellite_num (satellite_num msg))
))
