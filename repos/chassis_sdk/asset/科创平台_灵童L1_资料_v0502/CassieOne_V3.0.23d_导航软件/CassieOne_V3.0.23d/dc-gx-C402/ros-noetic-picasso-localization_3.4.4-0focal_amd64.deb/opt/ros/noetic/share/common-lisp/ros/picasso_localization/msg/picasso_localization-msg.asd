
(cl:in-package :asdf)

(defsystem "picasso_localization-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :sensor_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "CloudInfo" :depends-on ("_package_CloudInfo"))
    (:file "_package_CloudInfo" :depends-on ("_package"))
    (:file "GnssState" :depends-on ("_package_GnssState"))
    (:file "_package_GnssState" :depends-on ("_package"))
    (:file "LocationState" :depends-on ("_package_LocationState"))
    (:file "_package_LocationState" :depends-on ("_package"))
  ))