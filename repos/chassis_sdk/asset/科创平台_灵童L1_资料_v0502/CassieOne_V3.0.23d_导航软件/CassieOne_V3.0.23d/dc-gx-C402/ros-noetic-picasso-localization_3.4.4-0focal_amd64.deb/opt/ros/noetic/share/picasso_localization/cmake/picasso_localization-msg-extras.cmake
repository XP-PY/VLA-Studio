set(picasso_localization_MESSAGE_FILES "msg/CloudInfo.msg;msg/GnssState.msg;msg/LocationState.msg")
set(picasso_localization_SERVICE_FILES "srv/CtrlCmd.srv")
