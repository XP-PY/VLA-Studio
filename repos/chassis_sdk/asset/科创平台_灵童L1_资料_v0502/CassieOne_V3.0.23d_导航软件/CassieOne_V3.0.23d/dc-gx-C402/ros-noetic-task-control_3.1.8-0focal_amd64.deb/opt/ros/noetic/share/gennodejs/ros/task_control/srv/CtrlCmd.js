// Auto-generated. Do not edit!

// (in-package task_control.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class CtrlCmdRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.cmd_ctl = null;
    }
    else {
      if (initObj.hasOwnProperty('cmd_ctl')) {
        this.cmd_ctl = initObj.cmd_ctl
      }
      else {
        this.cmd_ctl = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CtrlCmdRequest
    // Serialize message field [cmd_ctl]
    bufferOffset = _serializer.char(obj.cmd_ctl, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CtrlCmdRequest
    let len;
    let data = new CtrlCmdRequest(null);
    // Deserialize message field [cmd_ctl]
    data.cmd_ctl = _deserializer.char(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_control/CtrlCmdRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '28bf04cdfdcfb386ca72a2dd50778f84';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Picasso common command control define
    char cmd_ctl
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CtrlCmdRequest(null);
    if (msg.cmd_ctl !== undefined) {
      resolved.cmd_ctl = msg.cmd_ctl;
    }
    else {
      resolved.cmd_ctl = 0
    }

    return resolved;
    }
};

class CtrlCmdResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.cmd_ack = null;
    }
    else {
      if (initObj.hasOwnProperty('cmd_ack')) {
        this.cmd_ack = initObj.cmd_ack
      }
      else {
        this.cmd_ack = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CtrlCmdResponse
    // Serialize message field [cmd_ack]
    bufferOffset = _serializer.char(obj.cmd_ack, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CtrlCmdResponse
    let len;
    let data = new CtrlCmdResponse(null);
    // Deserialize message field [cmd_ack]
    data.cmd_ack = _deserializer.char(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_control/CtrlCmdResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8879dc8883cc4873f63e06ce71fd1043';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    char cmd_ack    # 0: finish; 1: fail;
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CtrlCmdResponse(null);
    if (msg.cmd_ack !== undefined) {
      resolved.cmd_ack = msg.cmd_ack;
    }
    else {
      resolved.cmd_ack = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: CtrlCmdRequest,
  Response: CtrlCmdResponse,
  md5sum() { return '2ed2e146e66344732d30669f245ca6cd'; },
  datatype() { return 'task_control/CtrlCmd'; }
};
