set(task_control_MESSAGE_FILES "msg/BaseState.msg;msg/TaskState.msg;msg/LocationState.msg")
set(task_control_SERVICE_FILES "srv/CtrlCmd.srv")
