
(cl:in-package :asdf)

(defsystem "task_control-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "BaseState" :depends-on ("_package_BaseState"))
    (:file "_package_BaseState" :depends-on ("_package"))
    (:file "LocationState" :depends-on ("_package_LocationState"))
    (:file "_package_LocationState" :depends-on ("_package"))
    (:file "TaskState" :depends-on ("_package_TaskState"))
    (:file "_package_TaskState" :depends-on ("_package"))
  ))