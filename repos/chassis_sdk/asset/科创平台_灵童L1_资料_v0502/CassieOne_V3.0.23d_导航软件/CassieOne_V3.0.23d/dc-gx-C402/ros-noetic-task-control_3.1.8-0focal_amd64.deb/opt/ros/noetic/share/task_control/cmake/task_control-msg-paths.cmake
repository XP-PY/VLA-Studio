# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${task_control_DIR}/.." "msg" task_control_MSG_INCLUDE_DIRS UNIQUE)
set(task_control_MSG_DEPENDENCIES std_msgs)
