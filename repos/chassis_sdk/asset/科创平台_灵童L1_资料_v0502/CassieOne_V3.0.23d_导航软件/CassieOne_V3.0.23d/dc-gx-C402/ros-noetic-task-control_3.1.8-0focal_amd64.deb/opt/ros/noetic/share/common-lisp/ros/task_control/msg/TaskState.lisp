; Auto-generated. Do not edit!


(cl:in-package task_control-msg)


;//! \htmlinclude TaskState.msg.html

(cl:defclass <TaskState> (roslisp-msg-protocol:ros-message)
  ((sys_ctrl_mode
    :reader sys_ctrl_mode
    :initarg :sys_ctrl_mode
    :type cl:fixnum
    :initform 0)
   (sys_fault_code
    :reader sys_fault_code
    :initarg :sys_fault_code
    :type cl:integer
    :initform 0)
   (location_state
    :reader location_state
    :initarg :location_state
    :type cl:fixnum
    :initform 0)
   (location_score
    :reader location_score
    :initarg :location_score
    :type cl:float
    :initform 0.0)
   (location_x
    :reader location_x
    :initarg :location_x
    :type cl:float
    :initform 0.0)
   (location_y
    :reader location_y
    :initarg :location_y
    :type cl:float
    :initform 0.0)
   (location_yaw
    :reader location_yaw
    :initarg :location_yaw
    :type cl:float
    :initform 0.0)
   (tracking_err_y
    :reader tracking_err_y
    :initarg :tracking_err_y
    :type cl:float
    :initform 0.0)
   (obst_stop_state
    :reader obst_stop_state
    :initarg :obst_stop_state
    :type cl:fixnum
    :initform 0)
   (avoid_policy
    :reader avoid_policy
    :initarg :avoid_policy
    :type cl:fixnum
    :initform 0)
   (ctrl_loop_mode
    :reader ctrl_loop_mode
    :initarg :ctrl_loop_mode
    :type cl:fixnum
    :initform 0))
)

(cl:defclass TaskState (<TaskState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TaskState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TaskState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name task_control-msg:<TaskState> is deprecated: use task_control-msg:TaskState instead.")))

(cl:ensure-generic-function 'sys_ctrl_mode-val :lambda-list '(m))
(cl:defmethod sys_ctrl_mode-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:sys_ctrl_mode-val is deprecated.  Use task_control-msg:sys_ctrl_mode instead.")
  (sys_ctrl_mode m))

(cl:ensure-generic-function 'sys_fault_code-val :lambda-list '(m))
(cl:defmethod sys_fault_code-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:sys_fault_code-val is deprecated.  Use task_control-msg:sys_fault_code instead.")
  (sys_fault_code m))

(cl:ensure-generic-function 'location_state-val :lambda-list '(m))
(cl:defmethod location_state-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:location_state-val is deprecated.  Use task_control-msg:location_state instead.")
  (location_state m))

(cl:ensure-generic-function 'location_score-val :lambda-list '(m))
(cl:defmethod location_score-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:location_score-val is deprecated.  Use task_control-msg:location_score instead.")
  (location_score m))

(cl:ensure-generic-function 'location_x-val :lambda-list '(m))
(cl:defmethod location_x-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:location_x-val is deprecated.  Use task_control-msg:location_x instead.")
  (location_x m))

(cl:ensure-generic-function 'location_y-val :lambda-list '(m))
(cl:defmethod location_y-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:location_y-val is deprecated.  Use task_control-msg:location_y instead.")
  (location_y m))

(cl:ensure-generic-function 'location_yaw-val :lambda-list '(m))
(cl:defmethod location_yaw-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:location_yaw-val is deprecated.  Use task_control-msg:location_yaw instead.")
  (location_yaw m))

(cl:ensure-generic-function 'tracking_err_y-val :lambda-list '(m))
(cl:defmethod tracking_err_y-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:tracking_err_y-val is deprecated.  Use task_control-msg:tracking_err_y instead.")
  (tracking_err_y m))

(cl:ensure-generic-function 'obst_stop_state-val :lambda-list '(m))
(cl:defmethod obst_stop_state-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:obst_stop_state-val is deprecated.  Use task_control-msg:obst_stop_state instead.")
  (obst_stop_state m))

(cl:ensure-generic-function 'avoid_policy-val :lambda-list '(m))
(cl:defmethod avoid_policy-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:avoid_policy-val is deprecated.  Use task_control-msg:avoid_policy instead.")
  (avoid_policy m))

(cl:ensure-generic-function 'ctrl_loop_mode-val :lambda-list '(m))
(cl:defmethod ctrl_loop_mode-val ((m <TaskState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader task_control-msg:ctrl_loop_mode-val is deprecated.  Use task_control-msg:ctrl_loop_mode instead.")
  (ctrl_loop_mode m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TaskState>) ostream)
  "Serializes a message object of type '<TaskState>"
  (cl:let* ((signed (cl:slot-value msg 'sys_ctrl_mode)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'sys_fault_code)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'location_state)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'location_score))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'location_x))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'location_y))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'location_yaw))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'tracking_err_y))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'obst_stop_state)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'avoid_policy)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'ctrl_loop_mode)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TaskState>) istream)
  "Deserializes a message object of type '<TaskState>"
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'sys_ctrl_mode) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'sys_fault_code) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'location_state) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'location_score) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'location_x) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'location_y) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'location_yaw) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'tracking_err_y) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'obst_stop_state) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'avoid_policy) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'ctrl_loop_mode) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TaskState>)))
  "Returns string type for a message object of type '<TaskState>"
  "task_control/TaskState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TaskState)))
  "Returns string type for a message object of type 'TaskState"
  "task_control/TaskState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TaskState>)))
  "Returns md5sum for a message object of type '<TaskState>"
  "22f1708db2529df1d647701aa124ab1e")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TaskState)))
  "Returns md5sum for a message object of type 'TaskState"
  "22f1708db2529df1d647701aa124ab1e")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TaskState>)))
  "Returns full string definition for message of type '<TaskState>"
  (cl:format cl:nil "int8        sys_ctrl_mode       # 1: manual; 2: auto;~%int32       sys_fault_code      # PLNS fault code~%int8        location_state      # 0: none; 1: sleeping; 2: success; 3: error;~%float32     location_score      # location score (0~~1)~%float32     location_x~%float32     location_y~%float32     location_yaw~%float32     tracking_err_y      # auto nav tracking err y~%int8        obst_stop_state     # 0: none; 1: obst stop;~%int8        avoid_policy        # 0: none; 1: stop; 2: avoid plan;~%int8        ctrl_loop_mode      # 0: none; 1: line; 2: rotate; 3: pure trace;~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TaskState)))
  "Returns full string definition for message of type 'TaskState"
  (cl:format cl:nil "int8        sys_ctrl_mode       # 1: manual; 2: auto;~%int32       sys_fault_code      # PLNS fault code~%int8        location_state      # 0: none; 1: sleeping; 2: success; 3: error;~%float32     location_score      # location score (0~~1)~%float32     location_x~%float32     location_y~%float32     location_yaw~%float32     tracking_err_y      # auto nav tracking err y~%int8        obst_stop_state     # 0: none; 1: obst stop;~%int8        avoid_policy        # 0: none; 1: stop; 2: avoid plan;~%int8        ctrl_loop_mode      # 0: none; 1: line; 2: rotate; 3: pure trace;~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TaskState>))
  (cl:+ 0
     1
     4
     1
     4
     4
     4
     4
     4
     1
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TaskState>))
  "Converts a ROS message object to a list"
  (cl:list 'TaskState
    (cl:cons ':sys_ctrl_mode (sys_ctrl_mode msg))
    (cl:cons ':sys_fault_code (sys_fault_code msg))
    (cl:cons ':location_state (location_state msg))
    (cl:cons ':location_score (location_score msg))
    (cl:cons ':location_x (location_x msg))
    (cl:cons ':location_y (location_y msg))
    (cl:cons ':location_yaw (location_yaw msg))
    (cl:cons ':tracking_err_y (tracking_err_y msg))
    (cl:cons ':obst_stop_state (obst_stop_state msg))
    (cl:cons ':avoid_policy (avoid_policy msg))
    (cl:cons ':ctrl_loop_mode (ctrl_loop_mode msg))
))
