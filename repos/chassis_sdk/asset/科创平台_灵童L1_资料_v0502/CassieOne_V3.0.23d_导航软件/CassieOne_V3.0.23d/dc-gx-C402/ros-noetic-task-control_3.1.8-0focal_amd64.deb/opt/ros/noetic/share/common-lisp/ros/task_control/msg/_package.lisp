(cl:defpackage task_control-msg
  (:use )
  (:export
   "<BASESTATE>"
   "BASESTATE"
   "<LOCATIONSTATE>"
   "LOCATIONSTATE"
   "<TASKSTATE>"
   "TASKSTATE"
  ))

