// Auto-generated. Do not edit!

// (in-package task_control.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class LocationState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.mode = null;
      this.state = null;
      this.laser_score = null;
      this.laser_x = null;
      this.laser_y = null;
      this.laser_yaw = null;
      this.gnss_msg_state = null;
      this.gnss_run_state = null;
      this.satellite_num = null;
      this.gnss_score = null;
      this.gnss_x = null;
      this.gnss_y = null;
      this.gnss_yaw = null;
    }
    else {
      if (initObj.hasOwnProperty('mode')) {
        this.mode = initObj.mode
      }
      else {
        this.mode = 0;
      }
      if (initObj.hasOwnProperty('state')) {
        this.state = initObj.state
      }
      else {
        this.state = 0;
      }
      if (initObj.hasOwnProperty('laser_score')) {
        this.laser_score = initObj.laser_score
      }
      else {
        this.laser_score = 0.0;
      }
      if (initObj.hasOwnProperty('laser_x')) {
        this.laser_x = initObj.laser_x
      }
      else {
        this.laser_x = 0.0;
      }
      if (initObj.hasOwnProperty('laser_y')) {
        this.laser_y = initObj.laser_y
      }
      else {
        this.laser_y = 0.0;
      }
      if (initObj.hasOwnProperty('laser_yaw')) {
        this.laser_yaw = initObj.laser_yaw
      }
      else {
        this.laser_yaw = 0.0;
      }
      if (initObj.hasOwnProperty('gnss_msg_state')) {
        this.gnss_msg_state = initObj.gnss_msg_state
      }
      else {
        this.gnss_msg_state = 0;
      }
      if (initObj.hasOwnProperty('gnss_run_state')) {
        this.gnss_run_state = initObj.gnss_run_state
      }
      else {
        this.gnss_run_state = 0;
      }
      if (initObj.hasOwnProperty('satellite_num')) {
        this.satellite_num = initObj.satellite_num
      }
      else {
        this.satellite_num = 0;
      }
      if (initObj.hasOwnProperty('gnss_score')) {
        this.gnss_score = initObj.gnss_score
      }
      else {
        this.gnss_score = 0.0;
      }
      if (initObj.hasOwnProperty('gnss_x')) {
        this.gnss_x = initObj.gnss_x
      }
      else {
        this.gnss_x = 0.0;
      }
      if (initObj.hasOwnProperty('gnss_y')) {
        this.gnss_y = initObj.gnss_y
      }
      else {
        this.gnss_y = 0.0;
      }
      if (initObj.hasOwnProperty('gnss_yaw')) {
        this.gnss_yaw = initObj.gnss_yaw
      }
      else {
        this.gnss_yaw = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LocationState
    // Serialize message field [mode]
    bufferOffset = _serializer.int8(obj.mode, buffer, bufferOffset);
    // Serialize message field [state]
    bufferOffset = _serializer.int8(obj.state, buffer, bufferOffset);
    // Serialize message field [laser_score]
    bufferOffset = _serializer.float32(obj.laser_score, buffer, bufferOffset);
    // Serialize message field [laser_x]
    bufferOffset = _serializer.float32(obj.laser_x, buffer, bufferOffset);
    // Serialize message field [laser_y]
    bufferOffset = _serializer.float32(obj.laser_y, buffer, bufferOffset);
    // Serialize message field [laser_yaw]
    bufferOffset = _serializer.float32(obj.laser_yaw, buffer, bufferOffset);
    // Serialize message field [gnss_msg_state]
    bufferOffset = _serializer.int8(obj.gnss_msg_state, buffer, bufferOffset);
    // Serialize message field [gnss_run_state]
    bufferOffset = _serializer.int8(obj.gnss_run_state, buffer, bufferOffset);
    // Serialize message field [satellite_num]
    bufferOffset = _serializer.int8(obj.satellite_num, buffer, bufferOffset);
    // Serialize message field [gnss_score]
    bufferOffset = _serializer.float32(obj.gnss_score, buffer, bufferOffset);
    // Serialize message field [gnss_x]
    bufferOffset = _serializer.float32(obj.gnss_x, buffer, bufferOffset);
    // Serialize message field [gnss_y]
    bufferOffset = _serializer.float32(obj.gnss_y, buffer, bufferOffset);
    // Serialize message field [gnss_yaw]
    bufferOffset = _serializer.float32(obj.gnss_yaw, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LocationState
    let len;
    let data = new LocationState(null);
    // Deserialize message field [mode]
    data.mode = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [state]
    data.state = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [laser_score]
    data.laser_score = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [laser_x]
    data.laser_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [laser_y]
    data.laser_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [laser_yaw]
    data.laser_yaw = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [gnss_msg_state]
    data.gnss_msg_state = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [gnss_run_state]
    data.gnss_run_state = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [satellite_num]
    data.satellite_num = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [gnss_score]
    data.gnss_score = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [gnss_x]
    data.gnss_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [gnss_y]
    data.gnss_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [gnss_yaw]
    data.gnss_yaw = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 37;
  }

  static datatype() {
    // Returns string type for a message object
    return 'task_control/LocationState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '64447d0d1b0a1f725b34418a825d3994';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int8    mode # 0:none; 1:laser; 2:gnss; 3:mix2; 4:ins(gnss+imu);
    int8    state # 0:none; 1:sleeping; 2:success; 3:error;
    float32 laser_score
    float32 laser_x
    float32 laser_y
    float32 laser_yaw
    int8    gnss_msg_state # 0:invalid; 1:single; 4:diff; 5:float; 0xFF:disconnect;
    int8    gnss_run_state # 0:none; 1:idle; 2:invalid; 3:calib_running; 4:calib_finished; 5:calib_error;
    int8    satellite_num
    float32 gnss_score
    float32 gnss_x
    float32 gnss_y
    float32 gnss_yaw
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LocationState(null);
    if (msg.mode !== undefined) {
      resolved.mode = msg.mode;
    }
    else {
      resolved.mode = 0
    }

    if (msg.state !== undefined) {
      resolved.state = msg.state;
    }
    else {
      resolved.state = 0
    }

    if (msg.laser_score !== undefined) {
      resolved.laser_score = msg.laser_score;
    }
    else {
      resolved.laser_score = 0.0
    }

    if (msg.laser_x !== undefined) {
      resolved.laser_x = msg.laser_x;
    }
    else {
      resolved.laser_x = 0.0
    }

    if (msg.laser_y !== undefined) {
      resolved.laser_y = msg.laser_y;
    }
    else {
      resolved.laser_y = 0.0
    }

    if (msg.laser_yaw !== undefined) {
      resolved.laser_yaw = msg.laser_yaw;
    }
    else {
      resolved.laser_yaw = 0.0
    }

    if (msg.gnss_msg_state !== undefined) {
      resolved.gnss_msg_state = msg.gnss_msg_state;
    }
    else {
      resolved.gnss_msg_state = 0
    }

    if (msg.gnss_run_state !== undefined) {
      resolved.gnss_run_state = msg.gnss_run_state;
    }
    else {
      resolved.gnss_run_state = 0
    }

    if (msg.satellite_num !== undefined) {
      resolved.satellite_num = msg.satellite_num;
    }
    else {
      resolved.satellite_num = 0
    }

    if (msg.gnss_score !== undefined) {
      resolved.gnss_score = msg.gnss_score;
    }
    else {
      resolved.gnss_score = 0.0
    }

    if (msg.gnss_x !== undefined) {
      resolved.gnss_x = msg.gnss_x;
    }
    else {
      resolved.gnss_x = 0.0
    }

    if (msg.gnss_y !== undefined) {
      resolved.gnss_y = msg.gnss_y;
    }
    else {
      resolved.gnss_y = 0.0
    }

    if (msg.gnss_yaw !== undefined) {
      resolved.gnss_yaw = msg.gnss_yaw;
    }
    else {
      resolved.gnss_yaw = 0.0
    }

    return resolved;
    }
};

module.exports = LocationState;
