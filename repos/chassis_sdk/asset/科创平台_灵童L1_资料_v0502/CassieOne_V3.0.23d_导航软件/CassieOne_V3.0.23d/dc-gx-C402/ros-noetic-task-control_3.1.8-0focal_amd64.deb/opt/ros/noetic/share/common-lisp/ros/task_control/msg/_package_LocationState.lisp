(cl:in-package task_control-msg)
(cl:export '(MODE-VAL
          MODE
          STATE-VAL
          STATE
          LASER_SCORE-VAL
          LASER_SCORE
          LASER_X-VAL
          LASER_X
          LASER_Y-VAL
          LASER_Y
          LASER_YAW-VAL
          LASER_YAW
          GNSS_MSG_STATE-VAL
          GNSS_MSG_STATE
          GNSS_RUN_STATE-VAL
          GNSS_RUN_STATE
          SATELLITE_NUM-VAL
          SATELLITE_NUM
          GNSS_SCORE-VAL
          GNSS_SCORE
          GNSS_X-VAL
          GNSS_X
          GNSS_Y-VAL
          GNSS_Y
          GNSS_YAW-VAL
          GNSS_YAW
))