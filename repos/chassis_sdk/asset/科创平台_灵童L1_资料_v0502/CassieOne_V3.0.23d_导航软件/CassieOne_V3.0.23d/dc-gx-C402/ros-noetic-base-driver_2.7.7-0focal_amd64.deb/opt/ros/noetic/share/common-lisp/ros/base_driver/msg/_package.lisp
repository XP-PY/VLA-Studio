(cl:defpackage base_driver-msg
  (:use )
  (:export
   "<BASESTATE>"
   "BASESTATE"
   "<TASKSTATE>"
   "TASKSTATE"
  ))

