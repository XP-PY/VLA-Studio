(cl:in-package base_driver-msg)
(cl:export '(SYS_CTRL_MODE-VAL
          SYS_CTRL_MODE
          SYS_FAULT_CODE-VAL
          SYS_FAULT_CODE
          LOCATION_STATE-VAL
          LOCATION_STATE
          LOCATION_SCORE-VAL
          LOCATION_SCORE
          LOCATION_X-VAL
          LOCATION_X
          LOCATION_Y-VAL
          LOCATION_Y
          LOCATION_YAW-VAL
          LOCATION_YAW
          TRACKING_ERR_Y-VAL
          TRACKING_ERR_Y
          OBST_STOP_STATE-VAL
          OBST_STOP_STATE
          AVOID_POLICY-VAL
          AVOID_POLICY
          CTRL_LOOP_MODE-VAL
          CTRL_LOOP_MODE
))