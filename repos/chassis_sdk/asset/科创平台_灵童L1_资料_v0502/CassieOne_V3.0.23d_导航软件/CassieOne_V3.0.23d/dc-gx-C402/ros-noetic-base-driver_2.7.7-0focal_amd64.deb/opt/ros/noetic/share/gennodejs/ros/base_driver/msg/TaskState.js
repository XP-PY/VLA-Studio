// Auto-generated. Do not edit!

// (in-package base_driver.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TaskState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sys_ctrl_mode = null;
      this.sys_fault_code = null;
      this.location_state = null;
      this.location_score = null;
      this.location_x = null;
      this.location_y = null;
      this.location_yaw = null;
      this.tracking_err_y = null;
      this.obst_stop_state = null;
      this.avoid_policy = null;
      this.ctrl_loop_mode = null;
    }
    else {
      if (initObj.hasOwnProperty('sys_ctrl_mode')) {
        this.sys_ctrl_mode = initObj.sys_ctrl_mode
      }
      else {
        this.sys_ctrl_mode = 0;
      }
      if (initObj.hasOwnProperty('sys_fault_code')) {
        this.sys_fault_code = initObj.sys_fault_code
      }
      else {
        this.sys_fault_code = 0;
      }
      if (initObj.hasOwnProperty('location_state')) {
        this.location_state = initObj.location_state
      }
      else {
        this.location_state = 0;
      }
      if (initObj.hasOwnProperty('location_score')) {
        this.location_score = initObj.location_score
      }
      else {
        this.location_score = 0.0;
      }
      if (initObj.hasOwnProperty('location_x')) {
        this.location_x = initObj.location_x
      }
      else {
        this.location_x = 0.0;
      }
      if (initObj.hasOwnProperty('location_y')) {
        this.location_y = initObj.location_y
      }
      else {
        this.location_y = 0.0;
      }
      if (initObj.hasOwnProperty('location_yaw')) {
        this.location_yaw = initObj.location_yaw
      }
      else {
        this.location_yaw = 0.0;
      }
      if (initObj.hasOwnProperty('tracking_err_y')) {
        this.tracking_err_y = initObj.tracking_err_y
      }
      else {
        this.tracking_err_y = 0.0;
      }
      if (initObj.hasOwnProperty('obst_stop_state')) {
        this.obst_stop_state = initObj.obst_stop_state
      }
      else {
        this.obst_stop_state = 0;
      }
      if (initObj.hasOwnProperty('avoid_policy')) {
        this.avoid_policy = initObj.avoid_policy
      }
      else {
        this.avoid_policy = 0;
      }
      if (initObj.hasOwnProperty('ctrl_loop_mode')) {
        this.ctrl_loop_mode = initObj.ctrl_loop_mode
      }
      else {
        this.ctrl_loop_mode = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskState
    // Serialize message field [sys_ctrl_mode]
    bufferOffset = _serializer.int8(obj.sys_ctrl_mode, buffer, bufferOffset);
    // Serialize message field [sys_fault_code]
    bufferOffset = _serializer.int32(obj.sys_fault_code, buffer, bufferOffset);
    // Serialize message field [location_state]
    bufferOffset = _serializer.int8(obj.location_state, buffer, bufferOffset);
    // Serialize message field [location_score]
    bufferOffset = _serializer.float32(obj.location_score, buffer, bufferOffset);
    // Serialize message field [location_x]
    bufferOffset = _serializer.float32(obj.location_x, buffer, bufferOffset);
    // Serialize message field [location_y]
    bufferOffset = _serializer.float32(obj.location_y, buffer, bufferOffset);
    // Serialize message field [location_yaw]
    bufferOffset = _serializer.float32(obj.location_yaw, buffer, bufferOffset);
    // Serialize message field [tracking_err_y]
    bufferOffset = _serializer.float32(obj.tracking_err_y, buffer, bufferOffset);
    // Serialize message field [obst_stop_state]
    bufferOffset = _serializer.int8(obj.obst_stop_state, buffer, bufferOffset);
    // Serialize message field [avoid_policy]
    bufferOffset = _serializer.int8(obj.avoid_policy, buffer, bufferOffset);
    // Serialize message field [ctrl_loop_mode]
    bufferOffset = _serializer.int8(obj.ctrl_loop_mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskState
    let len;
    let data = new TaskState(null);
    // Deserialize message field [sys_ctrl_mode]
    data.sys_ctrl_mode = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [sys_fault_code]
    data.sys_fault_code = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [location_state]
    data.location_state = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [location_score]
    data.location_score = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [location_x]
    data.location_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [location_y]
    data.location_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [location_yaw]
    data.location_yaw = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [tracking_err_y]
    data.tracking_err_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [obst_stop_state]
    data.obst_stop_state = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [avoid_policy]
    data.avoid_policy = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [ctrl_loop_mode]
    data.ctrl_loop_mode = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 29;
  }

  static datatype() {
    // Returns string type for a message object
    return 'base_driver/TaskState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '22f1708db2529df1d647701aa124ab1e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int8        sys_ctrl_mode       # 1: manual; 2: auto;
    int32       sys_fault_code      # PLNS fault code
    int8        location_state      # 0: none; 1: sleeping; 2: success; 3: error;
    float32     location_score      # location score (0~1)
    float32     location_x
    float32     location_y
    float32     location_yaw
    float32     tracking_err_y      # auto nav tracking err y
    int8        obst_stop_state     # 0: none; 1: obst stop;
    int8        avoid_policy        # 0: none; 1: stop; 2: avoid plan;
    int8        ctrl_loop_mode      # 0: none; 1: line; 2: rotate; 3: pure trace;
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskState(null);
    if (msg.sys_ctrl_mode !== undefined) {
      resolved.sys_ctrl_mode = msg.sys_ctrl_mode;
    }
    else {
      resolved.sys_ctrl_mode = 0
    }

    if (msg.sys_fault_code !== undefined) {
      resolved.sys_fault_code = msg.sys_fault_code;
    }
    else {
      resolved.sys_fault_code = 0
    }

    if (msg.location_state !== undefined) {
      resolved.location_state = msg.location_state;
    }
    else {
      resolved.location_state = 0
    }

    if (msg.location_score !== undefined) {
      resolved.location_score = msg.location_score;
    }
    else {
      resolved.location_score = 0.0
    }

    if (msg.location_x !== undefined) {
      resolved.location_x = msg.location_x;
    }
    else {
      resolved.location_x = 0.0
    }

    if (msg.location_y !== undefined) {
      resolved.location_y = msg.location_y;
    }
    else {
      resolved.location_y = 0.0
    }

    if (msg.location_yaw !== undefined) {
      resolved.location_yaw = msg.location_yaw;
    }
    else {
      resolved.location_yaw = 0.0
    }

    if (msg.tracking_err_y !== undefined) {
      resolved.tracking_err_y = msg.tracking_err_y;
    }
    else {
      resolved.tracking_err_y = 0.0
    }

    if (msg.obst_stop_state !== undefined) {
      resolved.obst_stop_state = msg.obst_stop_state;
    }
    else {
      resolved.obst_stop_state = 0
    }

    if (msg.avoid_policy !== undefined) {
      resolved.avoid_policy = msg.avoid_policy;
    }
    else {
      resolved.avoid_policy = 0
    }

    if (msg.ctrl_loop_mode !== undefined) {
      resolved.ctrl_loop_mode = msg.ctrl_loop_mode;
    }
    else {
      resolved.ctrl_loop_mode = 0
    }

    return resolved;
    }
};

module.exports = TaskState;
