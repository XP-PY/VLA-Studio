
"use strict";

let TaskState = require('./TaskState.js');
let BaseState = require('./BaseState.js');

module.exports = {
  TaskState: TaskState,
  BaseState: BaseState,
};
