set(base_driver_MESSAGE_FILES "msg/BaseState.msg;msg/TaskState.msg")
set(base_driver_SERVICE_FILES "srv/CtrlCmd.srv")
