// Auto-generated. Do not edit!

// (in-package base_driver.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class BaseState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.base_fault_code = null;
      this.base_mileage = null;
      this.battery_voltage = null;
      this.battery_current = null;
      this.battery_percentage = null;
    }
    else {
      if (initObj.hasOwnProperty('base_fault_code')) {
        this.base_fault_code = initObj.base_fault_code
      }
      else {
        this.base_fault_code = 0;
      }
      if (initObj.hasOwnProperty('base_mileage')) {
        this.base_mileage = initObj.base_mileage
      }
      else {
        this.base_mileage = 0.0;
      }
      if (initObj.hasOwnProperty('battery_voltage')) {
        this.battery_voltage = initObj.battery_voltage
      }
      else {
        this.battery_voltage = 0.0;
      }
      if (initObj.hasOwnProperty('battery_current')) {
        this.battery_current = initObj.battery_current
      }
      else {
        this.battery_current = 0.0;
      }
      if (initObj.hasOwnProperty('battery_percentage')) {
        this.battery_percentage = initObj.battery_percentage
      }
      else {
        this.battery_percentage = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BaseState
    // Serialize message field [base_fault_code]
    bufferOffset = _serializer.int32(obj.base_fault_code, buffer, bufferOffset);
    // Serialize message field [base_mileage]
    bufferOffset = _serializer.float32(obj.base_mileage, buffer, bufferOffset);
    // Serialize message field [battery_voltage]
    bufferOffset = _serializer.float32(obj.battery_voltage, buffer, bufferOffset);
    // Serialize message field [battery_current]
    bufferOffset = _serializer.float32(obj.battery_current, buffer, bufferOffset);
    // Serialize message field [battery_percentage]
    bufferOffset = _serializer.float32(obj.battery_percentage, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BaseState
    let len;
    let data = new BaseState(null);
    // Deserialize message field [base_fault_code]
    data.base_fault_code = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [base_mileage]
    data.base_mileage = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [battery_voltage]
    data.battery_voltage = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [battery_current]
    data.battery_current = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [battery_percentage]
    data.battery_percentage = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'base_driver/BaseState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '977e22e579d0c02fa062adbcd15394aa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32       base_fault_code
    float32     base_mileage
    float32     battery_voltage
    float32     battery_current
    float32     battery_percentage
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BaseState(null);
    if (msg.base_fault_code !== undefined) {
      resolved.base_fault_code = msg.base_fault_code;
    }
    else {
      resolved.base_fault_code = 0
    }

    if (msg.base_mileage !== undefined) {
      resolved.base_mileage = msg.base_mileage;
    }
    else {
      resolved.base_mileage = 0.0
    }

    if (msg.battery_voltage !== undefined) {
      resolved.battery_voltage = msg.battery_voltage;
    }
    else {
      resolved.battery_voltage = 0.0
    }

    if (msg.battery_current !== undefined) {
      resolved.battery_current = msg.battery_current;
    }
    else {
      resolved.battery_current = 0.0
    }

    if (msg.battery_percentage !== undefined) {
      resolved.battery_percentage = msg.battery_percentage;
    }
    else {
      resolved.battery_percentage = 0.0
    }

    return resolved;
    }
};

module.exports = BaseState;
