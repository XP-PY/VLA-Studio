# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${base_driver_DIR}/.." "msg" base_driver_MSG_INCLUDE_DIRS UNIQUE)
set(base_driver_MSG_DEPENDENCIES std_msgs)
