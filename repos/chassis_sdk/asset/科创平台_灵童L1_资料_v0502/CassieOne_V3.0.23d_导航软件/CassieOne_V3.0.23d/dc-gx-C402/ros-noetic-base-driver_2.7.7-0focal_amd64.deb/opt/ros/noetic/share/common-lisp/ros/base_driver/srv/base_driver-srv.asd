
(cl:in-package :asdf)

(defsystem "base_driver-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "CtrlCmd" :depends-on ("_package_CtrlCmd"))
    (:file "_package_CtrlCmd" :depends-on ("_package"))
  ))