; Auto-generated. Do not edit!


(cl:in-package base_driver-msg)


;//! \htmlinclude BaseState.msg.html

(cl:defclass <BaseState> (roslisp-msg-protocol:ros-message)
  ((base_fault_code
    :reader base_fault_code
    :initarg :base_fault_code
    :type cl:integer
    :initform 0)
   (base_mileage
    :reader base_mileage
    :initarg :base_mileage
    :type cl:float
    :initform 0.0)
   (battery_voltage
    :reader battery_voltage
    :initarg :battery_voltage
    :type cl:float
    :initform 0.0)
   (battery_current
    :reader battery_current
    :initarg :battery_current
    :type cl:float
    :initform 0.0)
   (battery_percentage
    :reader battery_percentage
    :initarg :battery_percentage
    :type cl:float
    :initform 0.0))
)

(cl:defclass BaseState (<BaseState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <BaseState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'BaseState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name base_driver-msg:<BaseState> is deprecated: use base_driver-msg:BaseState instead.")))

(cl:ensure-generic-function 'base_fault_code-val :lambda-list '(m))
(cl:defmethod base_fault_code-val ((m <BaseState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader base_driver-msg:base_fault_code-val is deprecated.  Use base_driver-msg:base_fault_code instead.")
  (base_fault_code m))

(cl:ensure-generic-function 'base_mileage-val :lambda-list '(m))
(cl:defmethod base_mileage-val ((m <BaseState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader base_driver-msg:base_mileage-val is deprecated.  Use base_driver-msg:base_mileage instead.")
  (base_mileage m))

(cl:ensure-generic-function 'battery_voltage-val :lambda-list '(m))
(cl:defmethod battery_voltage-val ((m <BaseState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader base_driver-msg:battery_voltage-val is deprecated.  Use base_driver-msg:battery_voltage instead.")
  (battery_voltage m))

(cl:ensure-generic-function 'battery_current-val :lambda-list '(m))
(cl:defmethod battery_current-val ((m <BaseState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader base_driver-msg:battery_current-val is deprecated.  Use base_driver-msg:battery_current instead.")
  (battery_current m))

(cl:ensure-generic-function 'battery_percentage-val :lambda-list '(m))
(cl:defmethod battery_percentage-val ((m <BaseState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader base_driver-msg:battery_percentage-val is deprecated.  Use base_driver-msg:battery_percentage instead.")
  (battery_percentage m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <BaseState>) ostream)
  "Serializes a message object of type '<BaseState>"
  (cl:let* ((signed (cl:slot-value msg 'base_fault_code)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'base_mileage))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'battery_voltage))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'battery_current))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'battery_percentage))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <BaseState>) istream)
  "Deserializes a message object of type '<BaseState>"
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'base_fault_code) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'base_mileage) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'battery_voltage) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'battery_current) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'battery_percentage) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<BaseState>)))
  "Returns string type for a message object of type '<BaseState>"
  "base_driver/BaseState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'BaseState)))
  "Returns string type for a message object of type 'BaseState"
  "base_driver/BaseState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<BaseState>)))
  "Returns md5sum for a message object of type '<BaseState>"
  "977e22e579d0c02fa062adbcd15394aa")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'BaseState)))
  "Returns md5sum for a message object of type 'BaseState"
  "977e22e579d0c02fa062adbcd15394aa")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<BaseState>)))
  "Returns full string definition for message of type '<BaseState>"
  (cl:format cl:nil "int32       base_fault_code~%float32     base_mileage~%float32     battery_voltage~%float32     battery_current~%float32     battery_percentage~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'BaseState)))
  "Returns full string definition for message of type 'BaseState"
  (cl:format cl:nil "int32       base_fault_code~%float32     base_mileage~%float32     battery_voltage~%float32     battery_current~%float32     battery_percentage~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <BaseState>))
  (cl:+ 0
     4
     4
     4
     4
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <BaseState>))
  "Converts a ROS message object to a list"
  (cl:list 'BaseState
    (cl:cons ':base_fault_code (base_fault_code msg))
    (cl:cons ':base_mileage (base_mileage msg))
    (cl:cons ':battery_voltage (battery_voltage msg))
    (cl:cons ':battery_current (battery_current msg))
    (cl:cons ':battery_percentage (battery_percentage msg))
))
