(cl:in-package base_driver-msg)
(cl:export '(BASE_FAULT_CODE-VAL
          BASE_FAULT_CODE
          BASE_MILEAGE-VAL
          BASE_MILEAGE
          BATTERY_VOLTAGE-VAL
          BATTERY_VOLTAGE
          BATTERY_CURRENT-VAL
          BATTERY_CURRENT
          BATTERY_PERCENTAGE-VAL
          BATTERY_PERCENTAGE
))