
(cl:in-package :asdf)

(defsystem "base_driver-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "BaseState" :depends-on ("_package_BaseState"))
    (:file "_package_BaseState" :depends-on ("_package"))
    (:file "TaskState" :depends-on ("_package_TaskState"))
    (:file "_package_TaskState" :depends-on ("_package"))
  ))