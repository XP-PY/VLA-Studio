(cl:in-package funny_mapping-srv)
(cl:export '(CMD_CTL-VAL
          CMD_CTL
          CMD_ACK-VAL
          CMD_ACK
))