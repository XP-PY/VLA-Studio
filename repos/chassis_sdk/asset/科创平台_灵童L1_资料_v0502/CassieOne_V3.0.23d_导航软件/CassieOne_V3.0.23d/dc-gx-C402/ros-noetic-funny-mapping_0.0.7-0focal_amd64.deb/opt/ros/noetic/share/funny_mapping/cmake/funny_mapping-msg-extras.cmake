set(funny_mapping_MESSAGE_FILES "")
set(funny_mapping_SERVICE_FILES "srv/CtrlCmd.srv")
