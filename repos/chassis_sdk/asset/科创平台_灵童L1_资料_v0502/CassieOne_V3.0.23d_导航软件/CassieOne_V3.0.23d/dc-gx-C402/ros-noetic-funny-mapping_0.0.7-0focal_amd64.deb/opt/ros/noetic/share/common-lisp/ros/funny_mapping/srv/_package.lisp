(cl:defpackage funny_mapping-srv
  (:use )
  (:export
   "CTRLCMD"
   "<CTRLCMD-REQUEST>"
   "CTRLCMD-REQUEST"
   "<CTRLCMD-RESPONSE>"
   "CTRLCMD-RESPONSE"
  ))

