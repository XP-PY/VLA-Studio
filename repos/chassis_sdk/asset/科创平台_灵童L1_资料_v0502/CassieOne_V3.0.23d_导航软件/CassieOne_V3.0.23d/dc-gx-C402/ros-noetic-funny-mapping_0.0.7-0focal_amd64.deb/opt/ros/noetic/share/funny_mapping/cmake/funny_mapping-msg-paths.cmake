# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${funny_mapping_DIR}/.." "" funny_mapping_MSG_INCLUDE_DIRS UNIQUE)
set(funny_mapping_MSG_DEPENDENCIES std_msgs)
