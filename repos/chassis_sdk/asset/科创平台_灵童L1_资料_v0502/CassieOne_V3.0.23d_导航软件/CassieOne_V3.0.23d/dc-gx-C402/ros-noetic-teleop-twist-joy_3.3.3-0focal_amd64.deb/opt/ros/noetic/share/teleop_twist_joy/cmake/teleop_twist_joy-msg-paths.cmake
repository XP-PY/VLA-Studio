# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${teleop_twist_joy_DIR}/.." "" teleop_twist_joy_MSG_INCLUDE_DIRS UNIQUE)
set(teleop_twist_joy_MSG_DEPENDENCIES std_msgs)
