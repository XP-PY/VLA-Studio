set(funny_location_MESSAGE_FILES "msg/GnssState.msg;msg/LocationState.msg")
set(funny_location_SERVICE_FILES "srv/LocationService.srv;srv/CtrlCmd.srv")
