; Auto-generated. Do not edit!


(cl:in-package funny_location-srv)


;//! \htmlinclude LocationService-request.msg.html

(cl:defclass <LocationService-request> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (request_mode
    :reader request_mode
    :initarg :request_mode
    :type cl:fixnum
    :initform 0)
   (map_name
    :reader map_name
    :initarg :map_name
    :type cl:string
    :initform "")
   (pose
    :reader pose
    :initarg :pose
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (location_mode
    :reader location_mode
    :initarg :location_mode
    :type cl:fixnum
    :initform 0))
)

(cl:defclass LocationService-request (<LocationService-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LocationService-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LocationService-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name funny_location-srv:<LocationService-request> is deprecated: use funny_location-srv:LocationService-request instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <LocationService-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:header-val is deprecated.  Use funny_location-srv:header instead.")
  (header m))

(cl:ensure-generic-function 'request_mode-val :lambda-list '(m))
(cl:defmethod request_mode-val ((m <LocationService-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:request_mode-val is deprecated.  Use funny_location-srv:request_mode instead.")
  (request_mode m))

(cl:ensure-generic-function 'map_name-val :lambda-list '(m))
(cl:defmethod map_name-val ((m <LocationService-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:map_name-val is deprecated.  Use funny_location-srv:map_name instead.")
  (map_name m))

(cl:ensure-generic-function 'pose-val :lambda-list '(m))
(cl:defmethod pose-val ((m <LocationService-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:pose-val is deprecated.  Use funny_location-srv:pose instead.")
  (pose m))

(cl:ensure-generic-function 'location_mode-val :lambda-list '(m))
(cl:defmethod location_mode-val ((m <LocationService-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:location_mode-val is deprecated.  Use funny_location-srv:location_mode instead.")
  (location_mode m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<LocationService-request>)))
    "Constants for message type '<LocationService-request>"
  '((:REQUEST_CHANGE_MAP . 1)
    (:REQUEST_RELOCATE . 2)
    (:REQUEST_CHANGE_LOCATE_MODE . 3)
    (:REQUEST_FINISH_MAPPING . 4)
    (:LOCATION_MODE_LIDAR_MATCH . 1)
    (:LOCATION_MODE_LIDAR_DR . 2))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'LocationService-request)))
    "Constants for message type 'LocationService-request"
  '((:REQUEST_CHANGE_MAP . 1)
    (:REQUEST_RELOCATE . 2)
    (:REQUEST_CHANGE_LOCATE_MODE . 3)
    (:REQUEST_FINISH_MAPPING . 4)
    (:LOCATION_MODE_LIDAR_MATCH . 1)
    (:LOCATION_MODE_LIDAR_DR . 2))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LocationService-request>) ostream)
  "Serializes a message object of type '<LocationService-request>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let* ((signed (cl:slot-value msg 'request_mode)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'map_name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'map_name))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose) ostream)
  (cl:let* ((signed (cl:slot-value msg 'location_mode)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LocationService-request>) istream)
  "Deserializes a message object of type '<LocationService-request>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'request_mode) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'map_name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'map_name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose) istream)
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'location_mode) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LocationService-request>)))
  "Returns string type for a service object of type '<LocationService-request>"
  "funny_location/LocationServiceRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LocationService-request)))
  "Returns string type for a service object of type 'LocationService-request"
  "funny_location/LocationServiceRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LocationService-request>)))
  "Returns md5sum for a message object of type '<LocationService-request>"
  "297876d4b165ac14ee41f857710694f4")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LocationService-request)))
  "Returns md5sum for a message object of type 'LocationService-request"
  "297876d4b165ac14ee41f857710694f4")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LocationService-request>)))
  "Returns full string definition for message of type '<LocationService-request>"
  (cl:format cl:nil "std_msgs/Header header~%~%int8 REQUEST_CHANGE_MAP = 1             # 切地图请求~%int8 REQUEST_RELOCATE = 2               # 重定位请求~%int8 REQUEST_CHANGE_LOCATE_MODE = 3     # 更改定位模式请求~%int8 REQUEST_FINISH_MAPPING = 4         # 结束建图请求~%int8 request_mode~%~%string map_name                         # 切地图及结束建图需指定地图路径，“/home/robot/map/test”，其中test是地图名~%geometry_msgs/Pose pose                 # 重定位位姿，重定位请求需要~%~%int8 LOCATION_MODE_LIDAR_MATCH = 1      # 激光匹配定位~%int8 LOCATION_MODE_LIDAR_DR = 2         # 激光里程计DR~%int8 location_mode~%~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LocationService-request)))
  "Returns full string definition for message of type 'LocationService-request"
  (cl:format cl:nil "std_msgs/Header header~%~%int8 REQUEST_CHANGE_MAP = 1             # 切地图请求~%int8 REQUEST_RELOCATE = 2               # 重定位请求~%int8 REQUEST_CHANGE_LOCATE_MODE = 3     # 更改定位模式请求~%int8 REQUEST_FINISH_MAPPING = 4         # 结束建图请求~%int8 request_mode~%~%string map_name                         # 切地图及结束建图需指定地图路径，“/home/robot/map/test”，其中test是地图名~%geometry_msgs/Pose pose                 # 重定位位姿，重定位请求需要~%~%int8 LOCATION_MODE_LIDAR_MATCH = 1      # 激光匹配定位~%int8 LOCATION_MODE_LIDAR_DR = 2         # 激光里程计DR~%int8 location_mode~%~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LocationService-request>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     1
     4 (cl:length (cl:slot-value msg 'map_name))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose))
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LocationService-request>))
  "Converts a ROS message object to a list"
  (cl:list 'LocationService-request
    (cl:cons ':header (header msg))
    (cl:cons ':request_mode (request_mode msg))
    (cl:cons ':map_name (map_name msg))
    (cl:cons ':pose (pose msg))
    (cl:cons ':location_mode (location_mode msg))
))
;//! \htmlinclude LocationService-response.msg.html

(cl:defclass <LocationService-response> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (request_mode
    :reader request_mode
    :initarg :request_mode
    :type cl:fixnum
    :initform 0)
   (success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (current_map
    :reader current_map
    :initarg :current_map
    :type cl:string
    :initform "")
   (current_pose
    :reader current_pose
    :initarg :current_pose
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (match_score
    :reader match_score
    :initarg :match_score
    :type cl:float
    :initform 0.0)
   (match_inlier_ratio
    :reader match_inlier_ratio
    :initarg :match_inlier_ratio
    :type cl:float
    :initform 0.0)
   (current_location_mode
    :reader current_location_mode
    :initarg :current_location_mode
    :type cl:integer
    :initform 0))
)

(cl:defclass LocationService-response (<LocationService-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LocationService-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LocationService-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name funny_location-srv:<LocationService-response> is deprecated: use funny_location-srv:LocationService-response instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <LocationService-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:header-val is deprecated.  Use funny_location-srv:header instead.")
  (header m))

(cl:ensure-generic-function 'request_mode-val :lambda-list '(m))
(cl:defmethod request_mode-val ((m <LocationService-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:request_mode-val is deprecated.  Use funny_location-srv:request_mode instead.")
  (request_mode m))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <LocationService-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:success-val is deprecated.  Use funny_location-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'current_map-val :lambda-list '(m))
(cl:defmethod current_map-val ((m <LocationService-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:current_map-val is deprecated.  Use funny_location-srv:current_map instead.")
  (current_map m))

(cl:ensure-generic-function 'current_pose-val :lambda-list '(m))
(cl:defmethod current_pose-val ((m <LocationService-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:current_pose-val is deprecated.  Use funny_location-srv:current_pose instead.")
  (current_pose m))

(cl:ensure-generic-function 'match_score-val :lambda-list '(m))
(cl:defmethod match_score-val ((m <LocationService-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:match_score-val is deprecated.  Use funny_location-srv:match_score instead.")
  (match_score m))

(cl:ensure-generic-function 'match_inlier_ratio-val :lambda-list '(m))
(cl:defmethod match_inlier_ratio-val ((m <LocationService-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:match_inlier_ratio-val is deprecated.  Use funny_location-srv:match_inlier_ratio instead.")
  (match_inlier_ratio m))

(cl:ensure-generic-function 'current_location_mode-val :lambda-list '(m))
(cl:defmethod current_location_mode-val ((m <LocationService-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:current_location_mode-val is deprecated.  Use funny_location-srv:current_location_mode instead.")
  (current_location_mode m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LocationService-response>) ostream)
  "Serializes a message object of type '<LocationService-response>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let* ((signed (cl:slot-value msg 'request_mode)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'current_map))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'current_map))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'current_pose) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'match_score))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'match_inlier_ratio))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'current_location_mode)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LocationService-response>) istream)
  "Deserializes a message object of type '<LocationService-response>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'request_mode) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'current_map) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'current_map) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'current_pose) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'match_score) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'match_inlier_ratio) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'current_location_mode) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LocationService-response>)))
  "Returns string type for a service object of type '<LocationService-response>"
  "funny_location/LocationServiceResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LocationService-response)))
  "Returns string type for a service object of type 'LocationService-response"
  "funny_location/LocationServiceResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LocationService-response>)))
  "Returns md5sum for a message object of type '<LocationService-response>"
  "297876d4b165ac14ee41f857710694f4")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LocationService-response)))
  "Returns md5sum for a message object of type 'LocationService-response"
  "297876d4b165ac14ee41f857710694f4")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LocationService-response>)))
  "Returns full string definition for message of type '<LocationService-response>"
  (cl:format cl:nil "std_msgs/Header header~%int8 request_mode~%bool success                            # 切地图/重定位/保存地图是否成功~%string current_map                      # 当前使用/保存的地图~%geometry_msgs/Pose current_pose         # 当前定位位姿~%float32 match_score                     # 当前匹配度~%float32 match_inlier_ratio              # 当前匹配内点率~%int32 current_location_mode             # 当前定位模式~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LocationService-response)))
  "Returns full string definition for message of type 'LocationService-response"
  (cl:format cl:nil "std_msgs/Header header~%int8 request_mode~%bool success                            # 切地图/重定位/保存地图是否成功~%string current_map                      # 当前使用/保存的地图~%geometry_msgs/Pose current_pose         # 当前定位位姿~%float32 match_score                     # 当前匹配度~%float32 match_inlier_ratio              # 当前匹配内点率~%int32 current_location_mode             # 当前定位模式~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LocationService-response>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     1
     1
     4 (cl:length (cl:slot-value msg 'current_map))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'current_pose))
     4
     4
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LocationService-response>))
  "Converts a ROS message object to a list"
  (cl:list 'LocationService-response
    (cl:cons ':header (header msg))
    (cl:cons ':request_mode (request_mode msg))
    (cl:cons ':success (success msg))
    (cl:cons ':current_map (current_map msg))
    (cl:cons ':current_pose (current_pose msg))
    (cl:cons ':match_score (match_score msg))
    (cl:cons ':match_inlier_ratio (match_inlier_ratio msg))
    (cl:cons ':current_location_mode (current_location_mode msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'LocationService)))
  'LocationService-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'LocationService)))
  'LocationService-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LocationService)))
  "Returns string type for a service object of type '<LocationService>"
  "funny_location/LocationService")