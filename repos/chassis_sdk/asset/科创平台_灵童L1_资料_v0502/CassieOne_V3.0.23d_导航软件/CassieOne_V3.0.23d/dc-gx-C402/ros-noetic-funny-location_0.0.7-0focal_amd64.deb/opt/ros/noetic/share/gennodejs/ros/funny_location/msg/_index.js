
"use strict";

let GnssState = require('./GnssState.js');
let LocationState = require('./LocationState.js');

module.exports = {
  GnssState: GnssState,
  LocationState: LocationState,
};
