
(cl:in-package :asdf)

(defsystem "funny_location-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "GnssState" :depends-on ("_package_GnssState"))
    (:file "_package_GnssState" :depends-on ("_package"))
    (:file "LocationState" :depends-on ("_package_LocationState"))
    (:file "_package_LocationState" :depends-on ("_package"))
  ))