(cl:defpackage funny_location-msg
  (:use )
  (:export
   "<GNSSSTATE>"
   "GNSSSTATE"
   "<LOCATIONSTATE>"
   "LOCATIONSTATE"
  ))

