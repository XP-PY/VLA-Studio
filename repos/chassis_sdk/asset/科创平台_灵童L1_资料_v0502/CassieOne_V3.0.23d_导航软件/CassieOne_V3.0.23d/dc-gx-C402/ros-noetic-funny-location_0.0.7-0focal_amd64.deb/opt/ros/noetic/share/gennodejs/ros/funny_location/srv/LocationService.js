// Auto-generated. Do not edit!

// (in-package funny_location.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class LocationServiceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.request_mode = null;
      this.map_name = null;
      this.pose = null;
      this.location_mode = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('request_mode')) {
        this.request_mode = initObj.request_mode
      }
      else {
        this.request_mode = 0;
      }
      if (initObj.hasOwnProperty('map_name')) {
        this.map_name = initObj.map_name
      }
      else {
        this.map_name = '';
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('location_mode')) {
        this.location_mode = initObj.location_mode
      }
      else {
        this.location_mode = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LocationServiceRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [request_mode]
    bufferOffset = _serializer.int8(obj.request_mode, buffer, bufferOffset);
    // Serialize message field [map_name]
    bufferOffset = _serializer.string(obj.map_name, buffer, bufferOffset);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [location_mode]
    bufferOffset = _serializer.int8(obj.location_mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LocationServiceRequest
    let len;
    let data = new LocationServiceRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [request_mode]
    data.request_mode = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [map_name]
    data.map_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [location_mode]
    data.location_mode = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.map_name);
    return length + 62;
  }

  static datatype() {
    // Returns string type for a service object
    return 'funny_location/LocationServiceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e148f86e88e2ca9f0c6e983f8b04b4a3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    int8 REQUEST_CHANGE_MAP = 1             # 切地图请求
    int8 REQUEST_RELOCATE = 2               # 重定位请求
    int8 REQUEST_CHANGE_LOCATE_MODE = 3     # 更改定位模式请求
    int8 REQUEST_FINISH_MAPPING = 4         # 结束建图请求
    int8 request_mode
    
    string map_name                         # 切地图及结束建图需指定地图路径，“/home/robot/map/test”，其中test是地图名
    geometry_msgs/Pose pose                 # 重定位位姿，重定位请求需要
    
    int8 LOCATION_MODE_LIDAR_MATCH = 1      # 激光匹配定位
    int8 LOCATION_MODE_LIDAR_DR = 2         # 激光里程计DR
    int8 location_mode
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LocationServiceRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.request_mode !== undefined) {
      resolved.request_mode = msg.request_mode;
    }
    else {
      resolved.request_mode = 0
    }

    if (msg.map_name !== undefined) {
      resolved.map_name = msg.map_name;
    }
    else {
      resolved.map_name = ''
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.Pose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.Pose()
    }

    if (msg.location_mode !== undefined) {
      resolved.location_mode = msg.location_mode;
    }
    else {
      resolved.location_mode = 0
    }

    return resolved;
    }
};

// Constants for message
LocationServiceRequest.Constants = {
  REQUEST_CHANGE_MAP: 1,
  REQUEST_RELOCATE: 2,
  REQUEST_CHANGE_LOCATE_MODE: 3,
  REQUEST_FINISH_MAPPING: 4,
  LOCATION_MODE_LIDAR_MATCH: 1,
  LOCATION_MODE_LIDAR_DR: 2,
}

class LocationServiceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.request_mode = null;
      this.success = null;
      this.current_map = null;
      this.current_pose = null;
      this.match_score = null;
      this.match_inlier_ratio = null;
      this.current_location_mode = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('request_mode')) {
        this.request_mode = initObj.request_mode
      }
      else {
        this.request_mode = 0;
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('current_map')) {
        this.current_map = initObj.current_map
      }
      else {
        this.current_map = '';
      }
      if (initObj.hasOwnProperty('current_pose')) {
        this.current_pose = initObj.current_pose
      }
      else {
        this.current_pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('match_score')) {
        this.match_score = initObj.match_score
      }
      else {
        this.match_score = 0.0;
      }
      if (initObj.hasOwnProperty('match_inlier_ratio')) {
        this.match_inlier_ratio = initObj.match_inlier_ratio
      }
      else {
        this.match_inlier_ratio = 0.0;
      }
      if (initObj.hasOwnProperty('current_location_mode')) {
        this.current_location_mode = initObj.current_location_mode
      }
      else {
        this.current_location_mode = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LocationServiceResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [request_mode]
    bufferOffset = _serializer.int8(obj.request_mode, buffer, bufferOffset);
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [current_map]
    bufferOffset = _serializer.string(obj.current_map, buffer, bufferOffset);
    // Serialize message field [current_pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.current_pose, buffer, bufferOffset);
    // Serialize message field [match_score]
    bufferOffset = _serializer.float32(obj.match_score, buffer, bufferOffset);
    // Serialize message field [match_inlier_ratio]
    bufferOffset = _serializer.float32(obj.match_inlier_ratio, buffer, bufferOffset);
    // Serialize message field [current_location_mode]
    bufferOffset = _serializer.int32(obj.current_location_mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LocationServiceResponse
    let len;
    let data = new LocationServiceResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [request_mode]
    data.request_mode = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [current_map]
    data.current_map = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [current_pose]
    data.current_pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [match_score]
    data.match_score = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [match_inlier_ratio]
    data.match_inlier_ratio = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_location_mode]
    data.current_location_mode = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.current_map);
    return length + 74;
  }

  static datatype() {
    // Returns string type for a service object
    return 'funny_location/LocationServiceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '311539932eba8ca31bfebfcac5e37b5c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    int8 request_mode
    bool success                            # 切地图/重定位/保存地图是否成功
    string current_map                      # 当前使用/保存的地图
    geometry_msgs/Pose current_pose         # 当前定位位姿
    float32 match_score                     # 当前匹配度
    float32 match_inlier_ratio              # 当前匹配内点率
    int32 current_location_mode             # 当前定位模式
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LocationServiceResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.request_mode !== undefined) {
      resolved.request_mode = msg.request_mode;
    }
    else {
      resolved.request_mode = 0
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.current_map !== undefined) {
      resolved.current_map = msg.current_map;
    }
    else {
      resolved.current_map = ''
    }

    if (msg.current_pose !== undefined) {
      resolved.current_pose = geometry_msgs.msg.Pose.Resolve(msg.current_pose)
    }
    else {
      resolved.current_pose = new geometry_msgs.msg.Pose()
    }

    if (msg.match_score !== undefined) {
      resolved.match_score = msg.match_score;
    }
    else {
      resolved.match_score = 0.0
    }

    if (msg.match_inlier_ratio !== undefined) {
      resolved.match_inlier_ratio = msg.match_inlier_ratio;
    }
    else {
      resolved.match_inlier_ratio = 0.0
    }

    if (msg.current_location_mode !== undefined) {
      resolved.current_location_mode = msg.current_location_mode;
    }
    else {
      resolved.current_location_mode = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: LocationServiceRequest,
  Response: LocationServiceResponse,
  md5sum() { return '297876d4b165ac14ee41f857710694f4'; },
  datatype() { return 'funny_location/LocationService'; }
};
