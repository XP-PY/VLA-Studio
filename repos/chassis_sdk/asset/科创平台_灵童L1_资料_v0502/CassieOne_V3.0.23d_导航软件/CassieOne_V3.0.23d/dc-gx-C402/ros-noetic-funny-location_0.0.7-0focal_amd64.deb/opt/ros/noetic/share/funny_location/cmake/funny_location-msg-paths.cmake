# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${funny_location_DIR}/.." "msg" funny_location_MSG_INCLUDE_DIRS UNIQUE)
set(funny_location_MSG_DEPENDENCIES std_msgs;geometry_msgs)
