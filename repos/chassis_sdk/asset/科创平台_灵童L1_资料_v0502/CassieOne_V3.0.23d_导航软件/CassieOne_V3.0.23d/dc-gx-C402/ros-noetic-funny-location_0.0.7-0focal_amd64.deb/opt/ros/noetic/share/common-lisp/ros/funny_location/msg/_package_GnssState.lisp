(cl:in-package funny_location-msg)
(cl:export '(STATE-VAL
          STATE
          GNSS_VALID-VAL
          GNSS_VALID
          SATELLITE_NUM-VAL
          SATELLITE_NUM
))