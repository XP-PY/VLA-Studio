(cl:in-package funny_location-srv)
(cl:export '(HEADER-VAL
          HEADER
          REQUEST_MODE-VAL
          REQUEST_MODE
          MAP_NAME-VAL
          MAP_NAME
          POSE-VAL
          POSE
          LOCATION_MODE-VAL
          LOCATION_MODE
          HEADER-VAL
          HEADER
          REQUEST_MODE-VAL
          REQUEST_MODE
          SUCCESS-VAL
          SUCCESS
          CURRENT_MAP-VAL
          CURRENT_MAP
          CURRENT_POSE-VAL
          CURRENT_POSE
          MATCH_SCORE-VAL
          MATCH_SCORE
          MATCH_INLIER_RATIO-VAL
          MATCH_INLIER_RATIO
          CURRENT_LOCATION_MODE-VAL
          CURRENT_LOCATION_MODE
))