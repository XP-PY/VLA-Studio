; Auto-generated. Do not edit!


(cl:in-package funny_location-srv)


;//! \htmlinclude CtrlCmd-request.msg.html

(cl:defclass <CtrlCmd-request> (roslisp-msg-protocol:ros-message)
  ((cmd_ctl
    :reader cmd_ctl
    :initarg :cmd_ctl
    :type cl:integer
    :initform 0))
)

(cl:defclass CtrlCmd-request (<CtrlCmd-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CtrlCmd-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CtrlCmd-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name funny_location-srv:<CtrlCmd-request> is deprecated: use funny_location-srv:CtrlCmd-request instead.")))

(cl:ensure-generic-function 'cmd_ctl-val :lambda-list '(m))
(cl:defmethod cmd_ctl-val ((m <CtrlCmd-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:cmd_ctl-val is deprecated.  Use funny_location-srv:cmd_ctl instead.")
  (cmd_ctl m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CtrlCmd-request>) ostream)
  "Serializes a message object of type '<CtrlCmd-request>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'cmd_ctl)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CtrlCmd-request>) istream)
  "Deserializes a message object of type '<CtrlCmd-request>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'cmd_ctl)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CtrlCmd-request>)))
  "Returns string type for a service object of type '<CtrlCmd-request>"
  "funny_location/CtrlCmdRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CtrlCmd-request)))
  "Returns string type for a service object of type 'CtrlCmd-request"
  "funny_location/CtrlCmdRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CtrlCmd-request>)))
  "Returns md5sum for a message object of type '<CtrlCmd-request>"
  "2ed2e146e66344732d30669f245ca6cd")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CtrlCmd-request)))
  "Returns md5sum for a message object of type 'CtrlCmd-request"
  "2ed2e146e66344732d30669f245ca6cd")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CtrlCmd-request>)))
  "Returns full string definition for message of type '<CtrlCmd-request>"
  (cl:format cl:nil "# Picasso common command control define~%char cmd_ctl~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CtrlCmd-request)))
  "Returns full string definition for message of type 'CtrlCmd-request"
  (cl:format cl:nil "# Picasso common command control define~%char cmd_ctl~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CtrlCmd-request>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CtrlCmd-request>))
  "Converts a ROS message object to a list"
  (cl:list 'CtrlCmd-request
    (cl:cons ':cmd_ctl (cmd_ctl msg))
))
;//! \htmlinclude CtrlCmd-response.msg.html

(cl:defclass <CtrlCmd-response> (roslisp-msg-protocol:ros-message)
  ((cmd_ack
    :reader cmd_ack
    :initarg :cmd_ack
    :type cl:integer
    :initform 0))
)

(cl:defclass CtrlCmd-response (<CtrlCmd-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CtrlCmd-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CtrlCmd-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name funny_location-srv:<CtrlCmd-response> is deprecated: use funny_location-srv:CtrlCmd-response instead.")))

(cl:ensure-generic-function 'cmd_ack-val :lambda-list '(m))
(cl:defmethod cmd_ack-val ((m <CtrlCmd-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader funny_location-srv:cmd_ack-val is deprecated.  Use funny_location-srv:cmd_ack instead.")
  (cmd_ack m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CtrlCmd-response>) ostream)
  "Serializes a message object of type '<CtrlCmd-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'cmd_ack)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CtrlCmd-response>) istream)
  "Deserializes a message object of type '<CtrlCmd-response>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'cmd_ack)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CtrlCmd-response>)))
  "Returns string type for a service object of type '<CtrlCmd-response>"
  "funny_location/CtrlCmdResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CtrlCmd-response)))
  "Returns string type for a service object of type 'CtrlCmd-response"
  "funny_location/CtrlCmdResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CtrlCmd-response>)))
  "Returns md5sum for a message object of type '<CtrlCmd-response>"
  "2ed2e146e66344732d30669f245ca6cd")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CtrlCmd-response)))
  "Returns md5sum for a message object of type 'CtrlCmd-response"
  "2ed2e146e66344732d30669f245ca6cd")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CtrlCmd-response>)))
  "Returns full string definition for message of type '<CtrlCmd-response>"
  (cl:format cl:nil "char cmd_ack    # 0: finish; 1: fail;~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CtrlCmd-response)))
  "Returns full string definition for message of type 'CtrlCmd-response"
  (cl:format cl:nil "char cmd_ack    # 0: finish; 1: fail;~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CtrlCmd-response>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CtrlCmd-response>))
  "Converts a ROS message object to a list"
  (cl:list 'CtrlCmd-response
    (cl:cons ':cmd_ack (cmd_ack msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'CtrlCmd)))
  'CtrlCmd-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'CtrlCmd)))
  'CtrlCmd-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CtrlCmd)))
  "Returns string type for a service object of type '<CtrlCmd>"
  "funny_location/CtrlCmd")