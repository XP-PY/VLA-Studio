
(cl:in-package :asdf)

(defsystem "funny_location-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "CtrlCmd" :depends-on ("_package_CtrlCmd"))
    (:file "_package_CtrlCmd" :depends-on ("_package"))
    (:file "LocationService" :depends-on ("_package_LocationService"))
    (:file "_package_LocationService" :depends-on ("_package"))
  ))