// Auto-generated. Do not edit!

// (in-package funny_location.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class GnssState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.state = null;
      this.gnss_valid = null;
      this.satellite_num = null;
    }
    else {
      if (initObj.hasOwnProperty('state')) {
        this.state = initObj.state
      }
      else {
        this.state = 0;
      }
      if (initObj.hasOwnProperty('gnss_valid')) {
        this.gnss_valid = initObj.gnss_valid
      }
      else {
        this.gnss_valid = 0;
      }
      if (initObj.hasOwnProperty('satellite_num')) {
        this.satellite_num = initObj.satellite_num
      }
      else {
        this.satellite_num = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GnssState
    // Serialize message field [state]
    bufferOffset = _serializer.int8(obj.state, buffer, bufferOffset);
    // Serialize message field [gnss_valid]
    bufferOffset = _serializer.int8(obj.gnss_valid, buffer, bufferOffset);
    // Serialize message field [satellite_num]
    bufferOffset = _serializer.int8(obj.satellite_num, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GnssState
    let len;
    let data = new GnssState(null);
    // Deserialize message field [state]
    data.state = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [gnss_valid]
    data.gnss_valid = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [satellite_num]
    data.satellite_num = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 3;
  }

  static datatype() {
    // Returns string type for a message object
    return 'funny_location/GnssState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b7977205a43280ad3cc25bb91c265bf9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int8    state           # 0:invalid; 1:single; 4:diff; 5:float; 0xFF:disconnect;
    int8    gnss_valid      # 0:invalid; 1:valid;
    int8    satellite_num
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GnssState(null);
    if (msg.state !== undefined) {
      resolved.state = msg.state;
    }
    else {
      resolved.state = 0
    }

    if (msg.gnss_valid !== undefined) {
      resolved.gnss_valid = msg.gnss_valid;
    }
    else {
      resolved.gnss_valid = 0
    }

    if (msg.satellite_num !== undefined) {
      resolved.satellite_num = msg.satellite_num;
    }
    else {
      resolved.satellite_num = 0
    }

    return resolved;
    }
};

module.exports = GnssState;
