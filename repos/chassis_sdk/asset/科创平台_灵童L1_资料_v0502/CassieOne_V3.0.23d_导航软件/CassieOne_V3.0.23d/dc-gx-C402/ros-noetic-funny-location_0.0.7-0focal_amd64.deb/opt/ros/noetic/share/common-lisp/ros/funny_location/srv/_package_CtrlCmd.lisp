(cl:in-package funny_location-srv)
(cl:export '(CMD_CTL-VAL
          CMD_CTL
          CMD_ACK-VAL
          CMD_ACK
))