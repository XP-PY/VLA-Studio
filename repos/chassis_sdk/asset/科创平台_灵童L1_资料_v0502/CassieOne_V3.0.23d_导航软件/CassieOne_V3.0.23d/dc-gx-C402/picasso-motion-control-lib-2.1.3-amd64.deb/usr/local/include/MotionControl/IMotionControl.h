/*
 * Copyright 2022 The Picasso Group Authors
 * 2022-03-05 chaosir <chaosir@picasso-robot.com>
 */

#ifndef _IMOTION_CONTROL_H
#define _IMOTION_CONTROL_H

#include "MotionStructs.h"

class IMotionControl
{
public:
    IMotionControl() {}
    virtual ~IMotionControl() {}

public:
    virtual void SetControllerPara(double fKpY, double fKiY, double fKpYaw, double fDistOffRoute4MC, double fSpeedPlanAccX, 
                                   double fSpeedPlanAccYaw, double fDistOffRoute4PP, double fRouteRes) = 0;
    virtual void SetMotionPara(double fSpeedYawMax, double fSpeedMax, double fAccUpMax, double fAccDownMax) = 0;
    virtual void SetStepPara(double fVelCurvityMin, int nRotateFinishDelay, int nTraceFinishDelay, bool isForwardControl) = 0;
    virtual EMotionControlStatus RotateControl(Pose posNow, Pose posGoal, Twist twist, double fLimitW, double fPlanW) = 0;
    virtual EMotionControlStatus PathTrace(Pose posNow, Pose posGoal, Twist twist, double fLimitVel, double fPlanVel) = 0;
    virtual EMotionControlStatus PathTraceLocal(Pose posNow, Pose posGoal, Twist twist, double fLimitVel, double fPlanVel) = 0;
    virtual bool IsAutoNavPause() = 0;
    virtual void AutoNavContinue() = 0;
    virtual void AutoNavPause() = 0;
    virtual void AutoNavTaskCancel() = 0;
    virtual void OutLimitVel(Twist *pVelCmd, double fVelMaxLimit, double fWMaxLimit) = 0;
    virtual void OutLimitAcc(Twist *pVelCmd, Twist velCmdLast, double fAcc, double fDec) = 0;
    virtual int GetMotionControlFaultCode() = 0;
    virtual int GetPassThroughStationState() = 0;
    virtual int UpdateLocalPlanPathPoint(std::vector<Pose> *pVecLocalPathPoints) = 0;
    virtual void SetObstacleAvoidMode(int mode) = 0;
    virtual int GetObstacleAvoidMode() = 0;
    virtual void SetExecStepRotateStepFinish() = 0;

    virtual bool CalcuPathToSteps(Pose poseNow) = 0;
    virtual bool CalcuStepToPoints(int nStepIndex) = 0;
    virtual Twist GetVelCmdAutoNav() = 0;
    virtual MotionErr GetMotionTrackingError() = 0;
    virtual void ClearExecStepParam() = 0;
    virtual void ClearVelCmdAutoNav() = 0;
    virtual int GetLoopMode() = 0;
    virtual double GetObstStopDist() = 0;
    virtual bool GetGoalRealPose(Pose &pose) = 0;
    virtual bool isPathRunning() = 0;
    virtual bool isInBackwardPath() = 0;
    virtual void SetPathRunning(bool isRunning) = 0;

    virtual int ClearRouteNetFile() = 0;
    virtual int LoadRouteNetFile() = 0;
    virtual int LoadMapFromFile() = 0;
    virtual int PathPlan2Station(Pose startPose, int nGoalStationId) = 0;
    virtual int PathPlan2Pose(Pose startPose, Pose goalPose, bool isEndStepRotateAllow) = 0;
    virtual bool GetRunPathsFromBestRoute(SingleRoute bestRoute, Pose startPose, int nGoalStationId) = 0;
    virtual int StationId2VectorIndex(int nStationId) = 0;
    virtual bool CheckStationIdValid(int nStationId) = 0;
    virtual bool GetStationRotateState(int nStationIdx) = 0;
    virtual int GetStationType(int nStationIdx) = 0;
    virtual int GetStationId(int nStationIdx) = 0;
    virtual Pose GetStationPose(int nStationIdx) = 0;
    virtual Path GetRunPath(int nPathIdx) = 0;
    virtual int GetRunPathSize() = 0;
    virtual void AddRunPath(Path &path) = 0;
    virtual void ClearRunPaths() = 0;
    virtual SingleRoute GetReachableRouteChecked(int nRouteIdx) = 0;
    virtual void ClearReachableRoutes() = 0;
    virtual std::vector<int> GetBatteryChargeStationsId() = 0;
    virtual std::vector<int> GetParkingStationsId() = 0;
};

IMotionControl* CreatMotionControl();

#endif // _IMOTION_CONTROL_H