/*
 * Copyright 2022 The Picasso Group Authors
 * 2022-03-05 chaosir <chaosir@picasso-robot.com>
 */

#ifndef _IPUBLIC_H
#define _IPUBLIC_H

#include <cmath>
#include <vector>

typedef struct _Pose
{
    double x;
    double y;
    double yaw;

    _Pose() : x(0.0), y(0.0), yaw(0.0) {}
    _Pose(double _x, double _y) : x(_x), y(_y), yaw(0.0) {}
    _Pose(double _x, double _y, double _yaw) : x(_x), y(_y), yaw(_yaw) {}

    bool operator==(const _Pose b) const
    {
        return (fabs(x - b.x) < 0.000001 && fabs(y - b.y) < 0.000001);
    }
} Pose;

typedef struct _Point
{
    int x;
    int y;

    _Point() : x(0), y(0) {}
    _Point(int _x, int _y) : x(_x), y(_y) {}

    bool operator==(const _Point b) const
    {
        return (x == b.x && y == b.y);
    }
} Point;

typedef struct _PointF
{
    double x;
    double y;

    _PointF() : x(0.0), y(0.0) {}
    _PointF(double _x, double _y) : x(_x), y(_y) {}

    bool operator==(const _PointF b) const
    {
        return (fabs(x - b.x) < 0.000001 && fabs(y - b.y) < 0.000001);
    }
} PointF;

typedef struct _Node
{
    int id;
    PointF point;
    Pose realpos;

    _Node() : id(0), point(), realpos() {}
    _Node(int _id) : id(_id), point(), realpos() {}
    _Node(int _id, PointF _point) : id(_id), point(_point), realpos() {}
    _Node(int _id, PointF _point, Pose _realpos) : id(_id), point(_point), realpos(_realpos) {}
    _Node(PointF _point, Pose _realpos) : id(0), point(_point), realpos(_realpos) {}
} Node;

typedef struct _Path
{
    enum PathType
    {
        PATH_ZERO = 0,
        PATH_LINE = 1,
        PATH_BEZIER = 2,
        PATH_ROTATE = 3
    };
    PathType type;

    Node ps;
    Node pe;
    Node pc;
    Node pd;

    double fRotateAngle;
    double fLimitV;
    double fLimitW;
    double fLimitAcc;
    double fLimitDec;
    double fObstStop;
    int nDirection;

    _Path() : type(PATH_ZERO), fRotateAngle(0.0), fLimitV(0.0), fLimitW(0.0), fLimitAcc(0.0), fLimitDec(0.0), fObstStop(0.0) {}
} Path;

typedef struct _SingleRoute
{
    std::vector<int> vecNodeIndex;
    double fRouteLength;
} SingleRoute;

#endif // _IPUBLIC_H