/*
 * Copyright 2022 The Picasso Group Authors
 * 2022-03-05 chaosir <chaosir@picasso-robot.com>
 */

#ifndef _MOTION_STRUCTS_H
#define _MOTION_STRUCTS_H

#include "IPublic.h"

// Motion control fault
#define MC_FAULT_NONE                           0x00000000
#define MC_FAULT_POSITION                       0x00100000
#define MC_FAULT_OFF_ROUTE                      0x00200000
#define MC_FAULT_SPEED                          0x00400000
#define MC_FAULT_GOAL_STOP                      0x00800000
#define MC_FAULT_PATH2STEP                      0x01000000
#define MC_FAULT_PATH_CURVITY                   0x02000000
#define MC_FAULT_PATH_NONE                      0x04000000
#define MC_FAULT_STEP_NONE                      0x08000000

// Value define more
#define VALUE_VEL_LIMIT_MAX                     3.0     // m/s rad/s
#define VALUE_OBST_SLOW_DOWN_JUDGE              0.2     // m/s
#define VALUE_PATH_CURVITY_MAX                  1.5     // const
#define VALUE_FAULT_SPEED_YAW_MAX               0.1     // rad/s
#define VALUE_FAULT_SPEED_X_MAX                 0.1     // m/s
#define VALUE_FAULT_YAW_MAX                     0.1     // rad
#define VALUE_FAULT_X_MAX                       0.1     // m
#define VALUE_STOP_DETECT_NUM                   10      // const
#define VALUE_STOP_DETECT_THRESHOLD             0.01    // m/s rad/s
#define VALUE_ARRIVE_DIST_THRESHOLD1            0.005   // m
#define VALUE_ARRIVE_DIST_THRESHOLD2            0.1     // m
#define VALUE_FAULT_ARRIVE_VEL_THRESHOLD        0.1     // m/s
#define VALUE_FAULT_ARRIVE_DIST_THRESHOLD       0.1     // m

enum EMotionControlStatus
{
    AGV_STATUS_RUNNING = 0,
    AGV_STATUS_COMPLETE,
    AGV_STATUS_TIMEOUT,
    AGV_STATUS_FAULT_MAJOR,         // major fault -> emergency stop
    AGV_STATUS_FAULT_MINOR          // minor fault -> warn users
};

enum EClosedLoopMode
{
    CLOSEDLOOP_MODE_NONE = 0,
    CLOSEDLOOP_MODE_LINE,           // controller for line
    CLOSEDLOOP_MODE_ROTATE,         // controller for rotate
    CLOSEDLOOP_MODE_PURE_TRACE,     // controller for pure pursuit
    CLOSEDLOOP_MODE_MACLAN          // controller only for maclan
};

enum EObstacleAvoidMode
{
    OBSTACLE_AVOID_MODE_NONE = 0,
    OBSTACLE_AVOID_MODE_WAIT,       // obstacle stop wait
    OBSTACLE_AVOID_MODE_REPLAN      // obstacle replan
};

typedef struct _AutoNav
{
    int nSpeedLevel;                // Auto speed level
    Pose GoalPos;                   // NavtoPose
} AutoNav;

typedef struct _Motion
{
    double vx;                      // vel
    double ax;                      // acc
    double dx;                      // dec
    double vy;
    double ay;
    double vyaw;
    double ayaw;

    _Motion() : vx(0.0), ax(0.0), dx(0.0), vy(0.0), ay(0.0), vyaw(0.0), ayaw(0.0) {}
} Motion;

typedef struct _SpeedPlan
{
    double timeRun;
    double timeFinish;

    _SpeedPlan() : timeRun(0.0), timeFinish(0.0) {}
} SpeedPlan;

typedef struct _MotionErr
{
    double x;
    double y; // dist2route
    double yaw;

    _MotionErr() : x(0.0), y(0.0), yaw(0.0) {}
} MotionErr;

typedef struct _AdrcParam
{
    double l1;
    double l2;
    double l3;
    double kp;
    double kd;
    double b;

    double r;
    double r1;
    double r2;
    double e;
    double z1;
    double z2;
    double z3;
    double u;
    double y;
    double d;
    double out;

    _AdrcParam() : l1(0.0), l2(0.0), l3(0.0), kp(0.0), kd(0.0), b(0.0), r(0.0), r1(0.0), r2(0.0),
                   e(0.0), z1(0.0), z2(0.0), z3(0.0), u(0.0), y(0.0), d(0.0), out(0.0) {}
} AdrcParam;

// Simple define for MotionControl and TaskControl
typedef struct _Twist
{
    double vx;
    double vy;
    double w;

    _Twist() : vx(0.0), vy(0.0), w(0.0) {}
} Twist;

typedef struct _Odom
{
    Pose pose;
    Twist twist;
} Odom;

// Execute step info for closedloop
// ------------------------------------------------------------------------------------
typedef struct _ExecStep
{
    EClosedLoopMode nLoopMode;  // 1: LINE; 2: ROTATE; 3: PURE_TRACE; 4: MACLAN; 
    int nPathStartIndex;        // path start index
    int nPathInOneStep;         // n paths in 1 step
    int nDirection;             // 0x01->forward, 0x02->backward
    double fObstStop;           // 0.0->disable, [0.2 3.0]->obststop, only 4 rotate

    _ExecStep() : nLoopMode(CLOSEDLOOP_MODE_NONE), nPathStartIndex(0), 
                  nPathInOneStep(0), nDirection(0), fObstStop(0.0) {}
} ExecStep;

typedef struct _ExecStepParam
{
    bool isPathRunning;         // exec plan start flag
    bool isPathToPoints;        // path to points before closed loop
    int nStepIndex;             // current step index
    int nPointIndex;            // current point index
    int nRotateStopCnt;         // waiting closed-loop finish
    int nStepFinishDelayCnt;    // waiting step finish and stop delay 0.5s

    _ExecStepParam() : isPathRunning(false), isPathToPoints(false), 
                       nStepIndex(0), nPointIndex(0), nRotateStopCnt(0), nStepFinishDelayCnt(0) {}
} ExecStepParam;

typedef struct _StepDiscrete
{
    enum PointType
    {
        PT_LINE = 1,
        PT_BEZIER = 2,
    };
    PointType type;
    Pose pos; // point pos, only use [x,y]
    double fLimitV;
    double fLimitW;
    double fLimitAcc;           // limit acc, default 0.3m/s^2
    double fLimitDec;           // limit dec, default 0.3m/s^2
    double fTangentAngle;
    double fObstStop;           // 0.0->disable, [0.2 3.0]->obststop dist
    int nStationIndex;          // -1: not on station; >=0: on station, index value;
} StepDiscrete;

#endif // _MOTION_STRUCTS_H