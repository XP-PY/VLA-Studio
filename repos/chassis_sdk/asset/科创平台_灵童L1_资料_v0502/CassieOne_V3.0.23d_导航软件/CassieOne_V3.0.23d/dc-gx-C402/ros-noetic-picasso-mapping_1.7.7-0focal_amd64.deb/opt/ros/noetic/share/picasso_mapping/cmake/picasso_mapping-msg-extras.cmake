set(picasso_mapping_MESSAGE_FILES "msg/CloudInfo.msg")
set(picasso_mapping_SERVICE_FILES "srv/CtrlCmd.srv")
