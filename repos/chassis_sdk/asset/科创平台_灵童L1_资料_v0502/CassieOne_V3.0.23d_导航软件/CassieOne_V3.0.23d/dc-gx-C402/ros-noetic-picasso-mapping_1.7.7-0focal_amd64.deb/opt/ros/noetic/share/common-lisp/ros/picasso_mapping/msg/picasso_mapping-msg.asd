
(cl:in-package :asdf)

(defsystem "picasso_mapping-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :sensor_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "CloudInfo" :depends-on ("_package_CloudInfo"))
    (:file "_package_CloudInfo" :depends-on ("_package"))
  ))