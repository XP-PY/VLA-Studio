(cl:defpackage picasso_mapping-msg
  (:use )
  (:export
   "<CLOUDINFO>"
   "CLOUDINFO"
  ))

