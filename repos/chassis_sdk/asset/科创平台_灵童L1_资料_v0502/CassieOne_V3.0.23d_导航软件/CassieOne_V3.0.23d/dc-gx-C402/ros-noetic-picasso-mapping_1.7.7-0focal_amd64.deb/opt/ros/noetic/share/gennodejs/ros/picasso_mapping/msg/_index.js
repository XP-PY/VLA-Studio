
"use strict";

let CloudInfo = require('./CloudInfo.js');

module.exports = {
  CloudInfo: CloudInfo,
};
